<?php

header("Location: instalar.php");

?>
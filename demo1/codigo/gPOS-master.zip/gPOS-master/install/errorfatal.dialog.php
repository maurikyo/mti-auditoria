<h2>Error irrecuperable</h2>

Se ha producido un error que no se puede solucionar automaticamente. La aplicación no se ha podido instalar.
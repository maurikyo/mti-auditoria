<?php

include("../tool.php");

header("content-type: text/css");

?>

/* Areas de cabecera que parecen pertenecer al iframe de listados*/
.AreaPagina {
  background-color: #ECE8DE;
  border: 0px none!important;
}

/* Elementos que flotan dentro de una cabecera AreaPagina */
.enAreaPagina {
 /* background-color: #ECE8DE;*/
 /*background-color: white;*/
}


/* Iframe con contenido html */
.AreaListados {
 /*background-color: white;*/
 height: 100%;border: 0px none;
}

/* Areas añadidas con controles extra */

.frameExtra {
 background-color: white;
 /*background-image: url(img/bg2.png);*/
 background-repeat: repeat-x;
}

/* Areas añadidas con controles extra */

.frameNormal {
 /*background-color: white;*/
 /*background-image: url(img/bg2.png);
 background-repeat: repeat-x;*/
 border: 0px none!important;
}

/* areas con fondo transparente, como labels */

.trans {
 background-color: none!important;
 border: 0px none!important;
}



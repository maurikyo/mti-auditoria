
<popupset>
  
  <popup id="AccionesBusquedaCompra" class="media">
     <menuitem label="<?php echo _("Recibir Productos")?>" oncommand="recibirProductos()" />
     <menuitem label="<?php echo _("Guardar Precios")?>" oncommand="guardarPrecios()" />
     <menuseparator />
     <menuitem label="<?php echo _("Ver Detalle") ?>"  oncommand="RevisarCompraSeleccionada()"/>
     <menuitem label="<?php echo _("Ver Observaciones") ?>" oncommand="VerObservCompra()"/>
  </popup>

</popupset>

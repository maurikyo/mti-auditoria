<?php
header('Location: ../../xulgpos.php'); 
exit();
?>

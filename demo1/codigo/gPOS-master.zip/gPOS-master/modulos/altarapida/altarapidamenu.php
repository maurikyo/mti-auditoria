
<popupset>
  
  <popup id="accionesTicket" class="media">
     <menuitem label="Quitar" oncommand="quitarTacolorSelect()"/>
  </popup>

</popupset>

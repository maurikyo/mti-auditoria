<?php
//Fixed GENACK
 ?>
<script>parent.location.href='../xulentrar.php';</script>
<vbox flex="1">
	<groupbox flex="1">
		<caption class="media" label="Imprimir"/>
		<iframe id="imprimir" flex="1" src="about:blank" style="background-color: white"/>
	</groupbox>
	<button class="media btn" image="img/gpos_volver.png" label="Volver TPV" oncommand="CerrarImprimir()"/>
</vbox>